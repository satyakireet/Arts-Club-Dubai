import { LightningElement, api } from 'lwc';
import qrcode from './qrcode.js';

export default class ShowContactQRCode extends LightningElement {

    @api recordid;
    @api firstname;
    @api lastname;
    @api salutation;
    @api memberid;

    renderedCallback() {
        console.log('recordId-->' + this.recordid)
        console.log('firstName-->' + this.firstname)
        console.log('lastName-->' + this.lastname)
        console.log('salutation-->' + this.salutation)
        console.log('memberid-->' + this.memberid)
        const qrCodeGenerated = new qrcode(0, 'H');
        var strForGenearationOfQRCode = `https://theartsclub-dev-ed.develop.lightning.force.com/lightning/n/MemberLogin?C__Id=${this.recordid}&C__firstName=${this.firstname}&C__lastName=${this.lastname}&C__Salutation=${this.salutation}&C__MemberId=${this.memberid}`;
        console.log('settttt' + strForGenearationOfQRCode)
        qrCodeGenerated.addData(strForGenearationOfQRCode);
        qrCodeGenerated.make();
        let element = this.template.querySelector(".qrcode2");
        element.innerHTML = qrCodeGenerated.createSvgTag({});
    }

}