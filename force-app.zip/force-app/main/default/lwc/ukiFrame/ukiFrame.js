import { LightningElement } from 'lwc';
export default class UkiFrame extends LightningElement {

}