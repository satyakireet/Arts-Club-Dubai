import { LightningElement, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { updateRecord } from 'lightning/uiRecordApi';
import ID_FIELD from '@salesforce/schema/Quote.Id';
import Payment_Status_FIELD from '@salesforce/schema/Quote.Payment_Status__c';
import updatePaymentStatus from '@salesforce/apex/MemberInvoiceClass.updatePaymentStatus';
import { CurrentPageReference } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class MembershipPaymentPage extends LightningElement {

   DisplayCardField = false;
   DisplayUPIField = false;
   amount = 0;
   firstName = '';
   lastName = '';
   email = '';
   memId='';
   paymentMethod = '';
   //value = 'upi';
   // installmentId = '';
   
 
   // Options for payment method combobox.
   get payment_options() {
       return [
           { label: 'UPI', value: 'upi' },
           { label: 'Debit Card', value: 'DirectDebit' },
           { label: 'Credit Card', value: 'CreditCard' },
       ];
   }

   //getMemberId

    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        this.values = JSON.stringify(currentPageReference);

        if (currentPageReference) {
            //console.log(currentPageReference);
            const urlValue = currentPageReference.state.MemId;
            console.log('urlValue');
            console.log(urlValue);

            if (urlValue) {
                // this.contactExist = true;
                this.memId = currentPageReference.state.MemId;
                    
            }
        }
    }
 
   // Capture field input
   handlePickvalChange(event) {
       if(event.detail.value === 'DirectDebit' || event.detail.value === 'CreditCard'){
            this.DisplayCardField = true;
            this.DisplayUPIField = false;
            console.log(event.detail.value, ' TRUE');
        } 
        else if(event.detail.value === 'upi') {
            this.DisplayUPIField = true;
            this.DisplayCardField = false;
            console.log('Inside UPI check upi'+this.DisplayUPIField);
            console.log('Inside UPI check cards'+this.DisplayCardField);
            console.log(event.detail.value, ' TRUE');
        }
        else{
            this.DisplayCardField = false;
            this.DisplayUPIField = false;
            console.log('Inside Final Else');
        }
      // this[event.target.name] = event.target.value;
   }

   //Update membership details
   getPayment(){
       updatePaymentStatus({memId:this.memId}).then(result=>{
           this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Contact updated',
                            variant: 'success'
                        })
                    );
       }).catch(error=>{
           console.error(error);
       })
//    const fields = {};
//    fields[ID_FIELD.fieldApiName] = '0Q05h000000iRdLCAU';
//    fields[Payment_Status_FIELD.fieldApiName] = 'Paid';

//    const recordInput = { fields };

//             updateRecord(recordInput)
//                 .then(() => {
//                     this.dispatchEvent(
//                         new ShowToastEvent({
//                             title: 'Success',
//                             message: 'Contact updated',
//                             variant: 'success'
//                         })
//                     );
//                     // Display fresh data in the form
//                     return refreshApex(this.contact);
//                 })
   }
}