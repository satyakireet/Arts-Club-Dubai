import { api, LightningElement, wire } from 'lwc';
import Profile_Picture from '@salesforce/resourceUrl/Profile_Picture';
import Membership from '@salesforce/resourceUrl/Membership';
import getMemberApplicationData from '@salesforce/apex/EventCardController.getMemberApplicationData'
import USER_ID from '@salesforce/user/Id';
import CONTACT_ID from '@salesforce/schema/User.ContactId';
import { CurrentPageReference } from 'lightning/navigation';
import ArtsClubLogoImage from '@salesforce/resourceUrl/ArtsClubLogoImage';
import { getRecord } from 'lightning/uiRecordApi';
import getBookingData from '@salesforce/apex/EventCardController.getBookingData'
import ProfilePhoto from '@salesforce/resourceUrl/ProfilePhoto';
import HotelImage from '@salesforce/resourceUrl/HotelImage';
//import MemberLoginDetails from '@salesforce/apex/MemberLoginController.MemberLoginDetails';
import getProfile from '@salesforce/apex/EventCardController.getUserProfilePhoto';

export default class QRReader extends LightningElement {
    values
    artsClubImage = ArtsClubLogoImage;
    confirstName
    conlastName
    salutation
    memberId;
    contactExist;
    contactNotExist = false;
    contactId;
    membershipType = 'Full Membership';
    emailId;
    phone;
    testUrl;
    resultData = []

    @api recordId;



    @wire(getRecord, { recordId: USER_ID, fields: [CONTACT_ID] }) wireuser({ error, data }) {
        if (error) {
            console.log('error--->', error)
        } else if (data) {
            this.contactID = data.fields.ContactId.value;
            console.log('ContactId-->' + this.contactID)
                //            this.getMemberApplicationDatas()
            this.getBookingDetails();

        }
    }

    getBookingDetails() {
        getBookingData({ UserId: USER_ID })
            .then(result => {
                if (result) {
                    this.resultData = result;
                    console.log('this.resultData:' + JSON.stringify(this.resultData));
                }
            })
            .catch(error => {
                console.log('error--->', error)
            });
    }

    getMemberApplicationDatas() {
        getMemberApplicationData({ ContactId: this.contactID })
            .then(result => {
                if (result) {
                    result.forEach(element => {
                        console.log(element)
                        this.date = element.CreatedDate
                        this.confirstName = element.Name;
                        this.conlastName = element.Last_Name__c;
                        this.salutation = element.Contact__r.Salutation;
                        this.memberId = element.Member_Id__c;                        
                        this.membershipType = element.Membership_Type__c;
                        this.emailId = element.Email_ID__c;
                        this.phone = element.Mobile__c;
                        console.log(' Member id');
                        console.log(this.memberId);
                    });
                    if (this.confirstName) {
                        this.contactExist = true;
                    } else {
                        this.contactNotExist = true;
                    }
                    // this.url = `lightning/n/MemberLogin?C__Id=${this.contactID}&C__firstName=${this.firstName}&C__lastName=${this.lastName}&C__Salutation=${this.salutation}`
                    //     //&C__MemberId=${memberId}
                    // console.log('In for' + this.url)
                }
            })
            .catch(error => {
                console.log('error--->', error)
            });
            this.profileImage();
    }






    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        this.values = JSON.stringify(currentPageReference);

        if (currentPageReference) {
            //console.log(currentPageReference);
            const urlValue = currentPageReference.state.C__Id;
            console.log('urlValue');
            console.log(urlValue);

            if (urlValue) {
                // this.contactExist = true;
                this.contactID = currentPageReference.state.C__Id;
                this.getMemberApplicationDatas()
                    // this.confirstName = currentPageReference.state.C__firstName;
                    // this.conlastName = currentPageReference.state.C__lastName;
                    // this.salutation = currentPageReference.state.C__Salutation;
                    //this.memberId = currentPageReference.state.C__MemberId;
                    // console.log('urlValue', urlValue);
                    //console.log(urlValue);
                    //console.log(this.memberId);

            }
        }
    }
    profileImage() {
        getProfile({ memId: this.recordId }).then(result => {
            this.profilePicUrl = 'https://theartsclub-dev-ed.develop.file.force.com/sfc/servlet.shepherd/version/download/0685h00000K31VK';
            console.log('ProfileUrl - '+result[0].VersionDataUrl);
            //this.testUrl = result[0].VersionDataUrl;
            //this.profilePicUrl = result[0].VersionDataUrl;
        }).catch(error => {
            console.log("user error:" + JSON.stringify(error));

        });
        return this.profilePicUrl;
    }
    get Hotelimage() {
        return HotelImage;
    }
    get MembershipImage() {
        return Membership;
    }

}