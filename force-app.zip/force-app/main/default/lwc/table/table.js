import { LightningElement } from 'lwc';
export default class Table extends LightningElement {

}