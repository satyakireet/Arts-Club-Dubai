import { LightningElement } from 'lwc';

export default class MemberPaymentPage extends LightningElement {

    height = '50px';
    referrerPolicy = 'no-referrer';
           //sandbox = '';
    url = 'https://theartsclub-dev-ed--c.develop.vf.force.com/apex/GooglePayUI?core.apexpages.request.devconsole=1';
    width = '25%';

    
    handleClickPayNow(event){
        console.log('Clicked');
    }
    
}