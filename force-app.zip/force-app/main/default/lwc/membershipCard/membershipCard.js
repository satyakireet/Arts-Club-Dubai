import { LightningElement, wire, api } from 'lwc';
import Profile_Picture from '@salesforce/resourceUrl/Profile_Picture';
import Membership from '@salesforce/resourceUrl/Membership';
import USER_ID from '@salesforce/user/Id';
import CONTACT_ID from '@salesforce/schema/User.ContactId';
import { getRecord } from 'lightning/uiRecordApi';
import getContactData from '@salesforce/apex/EventCardController.getContactData';
import artClubImages from '@salesforce/resourceUrl/artClubImages';

export default class MembershipCard extends LightningElement {
    contactID
    resultData = []
    url
    @api recordId
    name
    date
    firstName
    lastName
    salutation
    @wire(getRecord, { recordId: USER_ID, fields: [CONTACT_ID] }) wireuser({ error, data }) {
        if (error) {
            console.log('error--->', error)
        } else if (data) {
            this.contactID = data.fields.ContactId.value;
            console.log('ContactId-->' + this.contactID)
            this.getContactData()
        }
    }
    getContactData() {
        getContactData({ ContactId: this.contactID })
            .then(result => {
                if (result) {
                    this.resultData = result
                    result.forEach(element => {
                        console.log(element)
                        this.name = element.Name;
                        this.date = element.CreatedDate
                        this.firstName = element.FirstName
                        this.lastName = element.LastName
                        this.salutation = element.Salutation
                    });
                    this.url = `lightning/n/MemberLogin?C__Id=${this.contactID}&C__firstName=${this.firstName}&C__lastName=${this.lastName}&C__Salutation=${this.salutation}`
                    console.log('In for' + this.url)
                }
            })
            .catch(error => {
                console.log('error--->', error)
            });
    }
    get artClubLogo() {
        return artClubImages + '/art_club_images/logo.jpg';
    }
    get Profileimage() {
        return Profile_Picture;
    }
    get MembershipImage() {
        return Membership;
    }

}