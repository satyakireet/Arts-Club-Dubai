import { LightningElement, wire } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation';

export default class VisitQRCodeReader extends LightningElement {
    memId;
    showMember = false;

    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        this.values = JSON.stringify(currentPageReference);

        if (currentPageReference) {
            //console.log(currentPageReference);
            const urlValue = currentPageReference.state.C__MemberId;
            console.log('urlValue');
            console.log(urlValue);

            if (urlValue) {
                this.showMember = true;
                this.memId = currentPageReference.state.C__MemberId;
            }
        }
    }
}