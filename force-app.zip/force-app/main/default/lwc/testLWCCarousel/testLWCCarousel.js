import { LightningElement } from 'lwc';

import p1 from '@salesforce/resourceUrl/Carousel1';
import p2 from '@salesforce/resourceUrl/Carousel2';
import p3 from '@salesforce/resourceUrl/Carousel3';
import p4 from '@salesforce/resourceUrl/Carousel4';
import p5 from '@salesforce/resourceUrl/Carousel5';
import p6 from '@salesforce/resourceUrl/Carousel6';

export default class TestLWCCarousel extends LightningElement {

    p1Url = p1;
    p2Url = p2;
    p3Url= p3;
    p4Url= p4;
    p5Url= p5;
    p6Url = p6;

    photos =[
        {
        id :"1",
        src: p1,
        header:'check',
        description:'Just to test some funct'

        },
    {
        id:"2",
        src: p2
    },
    {
        id:"3",
        src: p3
    },
    {
        id:"4",
        src: p4
    },
    {
        id:"5",
        src: p5
    }]
}