import { LightningElement,wire } from 'lwc';

import USER_ID from '@salesforce/user/Id';
import getMemApplnInfo from '@salesforce/apex/MembershipApplicationController.getMemApplnInfo';
import { NavigationMixin } from 'lightning/navigation';  

const COLUMNS = [  
    { label: 'Id', fieldName: 'Id' },  
    { label: 'Name', fieldName: 'Name' },  
    { label: 'Status', fieldName: 'Status__c' },  
    { type: "button", typeAttributes: {  
        label: 'View',  
        name: 'View',  
        title: 'View',  
        disabled: false,  
        value: 'view',  
        iconPosition: 'left'  
    } }
];  

export default class RegistrationFormPhase2 extends NavigationMixin(LightningElement) {

    ApplnList;
    columns = COLUMNS;

    @wire(getMemApplnInfo,{userId: USER_ID})
    InfoHandler(response){
       // this.wiredContactResponse2 = response;
        if(response.data){
            console.log('response.data');
            console.log(response.data);
            
            this.ApplnList = response.data;
        }
        else if(response.error){
            console.log(response.error);
        }
    }

    callRowAction( event ) { 

        const recId =  event.detail.row.Id;  
        const actionName = event.detail.action.name;

        if ( actionName === 'View') {  

            this[NavigationMixin.Navigate]({  
                type: 'standard__recordPage',  
                attributes: {  
                    recordId: recId,  
                    objectApiName: 'Account',  
                    actionName: 'view'  
                }  
            })  
        }
    }
}