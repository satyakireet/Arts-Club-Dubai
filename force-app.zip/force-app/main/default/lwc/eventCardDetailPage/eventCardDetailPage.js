import { LightningElement, wire } from 'lwc';
import USER_ID from '@salesforce/user/Id';
import createBooking from '@salesforce/apex/EventCardController.createBooking';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class EventCardDetailPage extends LightningElement {

    getData
    UserId;
		isModalOpen = false;
		guestNumber = 0;
		showPayButton = false;
		
		  height = '50px';
				referrerPolicy = 'no-referrer';
				//sandbox = '';
				url = 'https://theartsclub-dev-ed--c.develop.vf.force.com/apex/GooglePayUI?core.apexpages.request.devconsole=1';
				width = '100%';
		
    openModal() {
        // to open modal set isModalOpen tarck value as true
        this.isModalOpen = true;
    }
    closeModal() {
        // to close modal set isModalOpen tarck value as false
        this.isModalOpen = false;
    }
		
    connectedCallback() {
        this.getData = JSON.parse(sessionStorage.getItem('recordData'))
        console.log('DATA__>>' + JSON.stringify(this.getData))
        console.log('userId-->' + USER_ID)
				
				if(this.getData.Price == 'Complimentary' || this.getData.Price == 'Minimum spends apply'){
						this.showPayButton = false;
				}else{
						this.showPayButton = true;
				}
    }
		handleGuestFieldChange(event){
				this.guestNumber = event.target.value;
		}
    handleClick(event) {
        console.log('value--->' + event.target.value)
        createBooking({ EventId: event.target.value, UserId: USER_ID ,guestQuantity :this.guestNumber})
            .then(result => {
                if (result) {
                    console.log('Data--->', result)
                    this.showToast('Success', 'You have been successfully registerd for the event', 'success');
										this.isModalOpen = false;
                }
            })
            .catch(error => {
                console.log('error--->', error)
                this.showToast('Error', 'Error in Booking', 'error');
								this.isModalOpen = false;
            });
    }
    showToast(title, message, variant) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: title,
                message: message,
                variant: variant
            })
        );
    }

    
}