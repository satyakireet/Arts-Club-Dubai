import { LightningElement, track,api,wire } from 'lwc';
import getRecordsDetails from '@salesforce/apex/MemberEventsDirectory.getRecordsDetails';
export default class eventIframe extends LightningElement  {
    @wire(getRecordsDetails, {eventId:'$recordId'}) eventdata;
    
}