import { LightningElement } from 'lwc';
import {CloseActionScreenEvent} from 'lightning/actions'

export default class TestMembership extends LightningElement {

    dataList =[
        {'Id' : 101, 'Name' : 'ABC',Score : '80'},
        {'Id' : 102, 'Name' : 'XYZ',Score : '40'},
        {'Id' : 103, 'Name' : 'MNO',Score : '90'},
        {'Id' : 104, 'Name' : 'EFG',Score : '25'},

    ]

    columnList =[
        {label : 'Id', fieldName: 'Id'},
        {label : 'Name', fieldName: 'Name'},
        {label : 'Progress', fieldName: 'Score',type:'progRing',typeAttributes:{variant:'warning'}}

    ]
    
    handleClick(){
        this.dispatchEvent(new CloseActionScreenEvent())
    }

}