import { LightningElement } from 'lwc';
export default class EventsDetailsPageArtsClub extends LightningElement {

}