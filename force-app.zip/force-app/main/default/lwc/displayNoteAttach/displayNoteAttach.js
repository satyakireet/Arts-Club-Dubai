import { LightningElement ,track} from 'lwc';
import getImage from '@salesforce/apex/DisplayNotesAttach.getMemberURL';


export default class DisplayNoteAttach extends LightningElement {
		content;
		imageUrl;
		
		connectedCallback(){
				console.log('>>>> connectedcallback');
				this.handleDisplay();
		}
		
	handleDisplay(event){
		getImage()
		.then(result => {
				console.log('>>>>',result);
			this.content = result;
			console.log('>>>>>>>>>>>>>>>>>>',this.content[0].Id);
				//this.imageUrl = '/sfc/servlet.shepherd/version/download/'+this.content[0].Id;
                console.log('result ==> ' + result);
                this.imageUrl = result;
				//this.imageUrl = 'https://theartsclub-dev-ed.develop.file.force.com/sfc/dist/version/download/?oid=00D5h00000878KP&ids=0685h00000KGojj&d=%2Fa%2F5h000000aPdd%2FXkppQ.d.plEZZWovaCAxaQtkCt6yf0WjZuP1a9a3ejw&asPdf=false';
				console.log('>>>>>>>>>>>>>>>>>>',this.imageUrl);
			this.error = undefined;
		})
		.catch(error => {
			this.error = error;
			this.accounts = undefined;
		})
	}
}