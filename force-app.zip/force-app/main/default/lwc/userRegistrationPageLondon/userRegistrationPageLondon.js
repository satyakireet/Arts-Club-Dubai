import { LightningElement,track } from 'lwc';

import saveRecord from '@salesforce/apex/MembershipApplicationController.createAppln';   
import { ShowToastEvent } from 'lightning/platformShowToastEvent';  
import ArtsClub from '@salesforce/resourceUrl/ArtsClubLondonHomePageImage';
const MAX_FILE_SIZE = 100000000; //10mb  
import saveProfilePhoto from '@salesforce/apex/MembershipApplicationController.saveProfilePhoto'; 
import saveOtherDocs from '@salesforce/apex/MembershipApplicationController.saveOtherDocs'; 


export default class UserRegistrationPageLondon extends LightningElement {

    artsClubimage =ArtsClub;

    @track Title;  
    @track LName;  
    @track fName;  
    @track pName;
    @track Nationality;  
    @track DateOB;  
    @track EmailI;  
    @track POBox; 
    @track phone;
    @track mobile;  
    @track spouse;  
    @track visited; 
    @track others; 
    @track otherRecordId;
    accountFields ={};
    //isRender =false;

    value = 'inProgress';
    ShowSpouseDetails =false;
    ShowPreviousDetails =false;

    get options() {
        return [
            { label: 'Unmarried', value: 'Unmarried' },
            { label: 'Married', value: 'Married' },
            
        ];
    }

    
    // File Upload
      myRecordId ='a005h00000jbXUrAAM';
      get acceptedFormats() {
        return ['.pdf', '.png','.xlsx','.xls','.csv','.doc','.docx'];
      }
    // File upload 
    
    /*  
    render(){
			if(this.isRender == false){
				return registrationPageTemplate;
			}
			else if(this.isRender == true){
				return fileUploadTemplate;  
			}
		}
    */

    handleChange(event){
      
         const {name,value} = event.target;
         this.accountFields[name] = value;
         console.log(this.accountFields); 
        
    }

    handleComboboxChange(event) {
      this.value = event.detail.value;
      console.log('Combobox1');
     // console.log(event.detail.value);
      if(event.detail.value == 'Married'){
        console.log('Combobox2');
        this.ShowSpouseDetails = true;
      }
      else {
        this.ShowSpouseDetails = false;
      }
  }

    handlePreviousChange(event) {
      console.log('Fired1');
      console.log(event.target.checked);

      if(event.target.checked == true){
        this.ShowPreviousDetails = true;
      }
      else {
        this.ShowPreviousDetails = false;
      }
      
      
  }
 
    createAppln(event) {  
 
       // Validations
 
       console.log('In submit handler 11');
 
       const info1 = this.template.querySelectorAll(".checkboxes");
       const info2 = this.template.querySelectorAll(".customCheckbox");
 
       const nameField = this.template.querySelector("lightning-input[data-id = 'inpFields1']").value;
       const emailField = this.template.querySelector("lightning-input[data-id = 'inpFields2']").value;
  
       //const info3 =this.template.querySelector("lightning-input-field[data-id = 'reqField']");
       let allCheckBoxValue1;
       let allCheckBoxValue2;
      
       Array.from(info1).forEach((element)=> {
          // console.log(element.checked);
           if(element.checked == false){
            allCheckBoxValue1 =false;
           }
       })
  
       Array.from(info2).forEach((element)=> {
        // console.log(element.checked);
         if(element.checked == false){
          allCheckBoxValue2 =false;
         }
     })
  
        
        if(allCheckBoxValue1 == false || allCheckBoxValue2 == false){
            const evt = new ShowToastEvent({
                title :'Error',
                message: 'Plese check all required checkbox',
                variant:'error'
            });
            this.dispatchEvent(evt);
  
        }
        else if(emailField == null || emailField == ''){
         const evt = new ShowToastEvent({
             title :'Error',
             message: 'Plese fill all required Fields',
             variant:'error'
         });
         this.dispatchEvent(evt);
 
     }
     else {
        console.log('Called or Not');
         this.saveRecord(); 
 
     }
 
    }  
    saveRecord() {  
 
      saveRecord({  
        applnRec: this.accountFields,  
        pageName: 'London'
      })  
        .then(applnId => {  
          if (applnId) { 
            //this.handleFileUpload(applnId);
            console.log('applnId'); 
            console.log(applnId);
            this.otherRecordId =applnId;
            

            this.dispatchEvent(  
              new ShowToastEvent({  
                title: 'Application Saved',  
                variant: 'success',  
                message: 'Thanks for reaching out! Your form Submit Succesfully and Our team will get back to you in sometime',  
              }),  
            );
            
            if(this.otherRecordId){
              this.buildFile();
            }

            //this.isRender = true;
          }  
        }).catch(error => {  
          console.log('error ', error);
          
        });  
    }  

  /*  

  // File Upload

  handlePhotoUpload(event) {
    
    //handleUploadFinished
    // Get the list of uploaded files
   // const uploadedFiles = event.detail.files;
    //alert('No. of files uploaded : ' + uploadedFiles.length);

    this.dispatchEvent(  
      new ShowToastEvent({  
        title: 'Photo Saved',  
        variant: 'success',  
        message: 'Thanks for reaching out! Your photo uploaded Successfully',  
      }),  
    );

  }

  
  handleOtherUploads(event) {

    this.dispatchEvent(  
      new ShowToastEvent({  
        title: 'Documents Saved',  
        variant: 'success',  
        message: 'Thanks for reaching out! Your Documents uploaded Successfully',  
      }),  
    );
  }
  */

  // File Upload for profile photo Start

  @track fileUploaded = false; // Render template
    @track fileNamesArr = []; // Display file names
    filesArr = []; // Store read file objects to pass to Apex
    filePromises = []; // Called my Promise.all
    @track showSpinner = true;
    isIdentificationRequired =true;

      // Handles front end; build FileReader object in a helper and call apex
      handleAddFiles(event) {
        if (event.target.files.length > 0) {
            // Validate file size
            for(let i = 0; i < event.target.files.length; i++) {
                let file = event.target.files[i]
                if(file.size > 1000000 ) {
                    // console.log('File too large, size: ' + file.size)
                    this.throwError('File is too large'); // Custom labels used
                    return;
                }
            }
            this.fileUploaded = true; // Show element
            if (this.isIdentificationRequired) { // Condition for multiple files
                for (let i = 0; i < event.target.files.length; i++) {
                    let file = event.target.files[i];
                    this.fileNamesArr.push({Name: file.name}); // Iterate html
                    this.filesArr.push(file);
                }
            } else { // Single file upload
                let file = event.target.files[0];
                this.fileNamesArray = [];
                this.fileNamesArr.push({Name: file.name});
                this.filesArr.push(file);
            }
        }
    }
    
    // Called by Submit button
    buildFile() { 
        for (let i = 0; i < this.filesArr.length; i++) {
            let build = new Promise((resolve, reject) => {
                    let freader = new FileReader();
                    freader.readAsDataURL(this.filesArr[i]); // reads file contents
                    freader.onload = f => {    // executes after successful read
                        let base64 = 'base64,';
                        let content = freader.result.indexOf(base64) + base64.length;
                        let fileContents = freader.result.substring(content);
                        resolve({ // returns a value after successful promise
                            Title: this.filesArr[i].name, // Store file name
                            VersionData: fileContents
                        })
                    };
                })
            this.filePromises.push(build); // filePromises called by Promise.all()
        }
        return Promise.all(this.filePromises) // Execute all file builds asynchronously
        .then(result => {
            this.handleSaveFiles(this.otherRecordId, result) // Pass file objects to Apex
        }) 
    }
    removeFiles(event)
    {
        this.fileUploaded = false;
        this.showSpinner = false;
        this.files = undefined; 
        this.fileNamesArr = []; 
        this.filesArr = [];
        this.filesUploaded = [];
    }
    handleSaveFiles(recordId, result) 
    {
        console.log('handleSaveFiles recordId: ' + recordId);
        saveProfilePhoto({ recordId: recordId, filesToInsert: result})
        .then(data => { 
          console.log('Exception'); 
          console.log(data);           
            const showSuccess = new ShowToastEvent({
                title: 'File Saved', // Custom label use
                message: data ,
                variant: 'Success',
            });
            this.dispatchEvent(showSuccess);
            
            if(this.OtherfilesArr){
              this.OtherbuildFile();
            } 
            this.fileNamesArray = [];

        })
        .catch(error => {
            const showError = new ShowToastEvent({
                title: 'Error!!',
                message: 'An Error occur while uploading the file. ' + error.message,
                variant: 'error',
            });
            this.dispatchEvent(showError);
        });
    }  

    // File Upload for profile photo End

    // File Upload for Rem Documents Start

    
  @track OtherfileUploaded = false; // Render template
  @track OtherfileNamesArr = []; // Display file names
  OtherfilesArr = []; // Store read file objects to pass to Apex
  OtherfilePromises = []; // Called my Promise.all
  @track OthershowSpinner = true;
  OtherisIdentificationRequired =true;
  OtherDocsResult;

    // Handles front end; build FileReader object in a helper and call apex
    handleOtherAddFiles(event) {
      console.log('event.target.files.length');
      console.log(event.target.files.length);
      if (event.target.files.length > 0) {
          // Validate file size
          for(let i = 0; i < event.target.files.length; i++) {
              let file = event.target.files[i]
              if(file.size > 1000000 ) {
                  // console.log('File too large, size: ' + file.size)
                  this.throwError('File is too large'); // Custom labels used
                  return;
              }
          }
          this.OtherfileUploaded = true; // Show element
          if (this.OtherisIdentificationRequired) {
            console.log('In If'); // Condition for multiple files
              for (let i = 0; i < event.target.files.length; i++) {
                  let file = event.target.files[i];
                  this.OtherfileNamesArr.push({Name: file.name}); // Iterate html
                  this.OtherfilesArr.push(file);
              }
          } else { // Single file upload
            console.log('In else');
              let file = event.target.files[0];
              this.OtherfileNamesArray = [];
              this.OtherfileNamesArr.push({Name: file.name});
              this.OtherfilesArr.push(file);
          }
      }
  }
  
  // Called by Submit button
  OtherbuildFile() { 
    console.log('this.OtherfilesArr.length');
    console.log(this.OtherfilesArr.length);
      for (let i = 0; i < this.OtherfilesArr.length; i++) {
          let build = new Promise((resolve, reject) => {
                  let freader = new FileReader();
                  freader.readAsDataURL(this.OtherfilesArr[i]); // reads file contents
                  freader.onload = f => {    // executes after successful read
                      let base64 = 'base64,';
                      let content = freader.result.indexOf(base64) + base64.length;
                      let fileContents = freader.result.substring(content);
                      resolve({ // returns a value after successful promise
                          Title: this.OtherfilesArr[i].name, // Store file name
                          VersionData: fileContents
                      })
                  };
              })
          this.OtherfilePromises.push(build); // filePromises called by Promise.all()
      }
      return Promise.all(this.OtherfilePromises) // Execute all file builds asynchronously
      .then(result => {
          this.handleOtherSaveFiles(this.otherRecordId,result) // Pass file objects to Apex
      }) 
  }
  removeOtherFiles(event)
  {
      this.OtherfileUploaded = false;
      this.OthershowSpinner = false;
      this.files = undefined; 
      this.OtherfileNamesArr = []; 
      this.OtherfilesArr = [];
      this.OtherfilesUploaded = [];
  }
  handleOtherSaveFiles(recordId, result) 
  {
      console.log('handleSaveFiles recordId: ' + recordId);
      saveOtherDocs({ recordId: recordId, filesToInsert: result})
      .then(data => {   
        /*         
          const showSuccess = new ShowToastEvent({
              title: 'File Saved', // Custom label use
              message: this.OtherfileNamesArr.length + ' File Uploaded Successfully ' ,
              variant: 'Success',
          });
          this.dispatchEvent(showSuccess); 
          */
          this.OtherfileNamesArray = [];
      })
      .catch(error => {
          const showError = new ShowToastEvent({
              title: 'Error!!',
              message: 'An Error occur while uploading the file. ' + error.message,
              variant: 'error',
          });
          this.dispatchEvent(showError);
      });
  }  



}