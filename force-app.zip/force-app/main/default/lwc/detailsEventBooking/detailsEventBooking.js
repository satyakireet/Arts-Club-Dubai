import { LightningElement } from 'lwc';
export default class DetailsEventBooking extends LightningElement {

}