import { api, LightningElement, wire ,track} from 'lwc';
import Profile_Picture from '@salesforce/resourceUrl/DavidProfile';
import Dubai_Profile from '@salesforce/resourceUrl/Profile_Picture';
import Rehan_Picture from '@salesforce/resourceUrl/rehan_profile';
import Amin_picture from '@salesforce/resourceUrl/amin_profile';
import artClubImages from '@salesforce/resourceUrl/artClubImages';
import YashClubManagement from '@salesforce/resourceUrl/YashClubManagement';
import DisplayYASHClubLogo from '@salesforce/label/c.DisplayYASHClubLogo';
import qrcode from './qrcode.js';
import USER_ID from '@salesforce/user/Id';
import CONTACT_ID from '@salesforce/schema/User.ContactId';
import USER_CITY from '@salesforce/schema/User.City';
import USER_PIC from '@salesforce/schema/User.SmallPhotoUrl';
import { getRecord } from 'lightning/uiRecordApi';
import artsclubDeviceLogos from '@salesforce/resourceUrl/artsclubDeviceLogos';
import getMemberApplicationData from '@salesforce/apex/EventCardController.getMemberApplicationData';
import getGoogleWalletDetails from '@salesforce/apex/GoogleWalletHandler.getGoogleWalletDetails';
import getCustomSettingData from '@salesforce/apex/EventCardController.getCustomSettingData';
import YASHProfile_Picture from '@salesforce/resourceUrl/profile';

import { NavigationMixin } from 'lightning/navigation';
import getProfile from '@salesforce/apex/profileCardHandler.getUserProfilePhoto';

export default class ShowVisitQRCode extends NavigationMixin(LightningElement) {

    //displayArtsClub=false;
    //@track displayYashClub=DisplayYASHClubLogo;
    displayYashClub;

    contactID;
    Profileimage =YASHProfile_Picture;
    resultData = []
    url;
    @api recordId;
    name
    date
    firstName
    lastName
    salutation;
    buttonLabel = 'Add to google wallet';
    showQrCode=false;
    showWalletButton = false;
    memberId;
    showSpinner = false;
    userCountry;
    userImage;
    userEmail;
    profilePicUrl;
    expiryDate;
    autoGenMemId;
    
    country;
    @track imageUrl;
    versionData;
   
    connectedCallback() {
        console.log('GetCLABEL-->'+this.displayYashClub);
        this.getCustomSettingForYashLogo();
    }
    getCustomSettingForYashLogo() {
        console.log('insidegetCustomSettingForYashLogo');
            getCustomSettingData()
                .then(result => {
                    this.displayYashClub = result.DisplayYashLogo__c;
                    //this.displayYashClub = this.result.DisplayYashLogo__c;
                    console.log('CheckYashLogo-->'+JSON.stringify(this.displayYashClub));
                })
                .catch(error => {
                    console.log('insideError');
                    this.error = error;
                });
        }
    

    @wire(getRecord, { recordId: USER_ID, fields: [CONTACT_ID,USER_CITY,USER_PIC] }) wireuser({ error, data }) {
        if (error) {
            console.log('error--->', error)
        } else if (data) {
            this.contactID = data.fields.ContactId.value;
            this.userCountry = data.fields.City.value;
            this.userImage = data.fields.SmallPhotoUrl.value;
            console.log('ContactId-->' + this.contactID);
            this.getMemberApplicationDatas();
        }
    }

    renderedCallback() {
        
    }

    getMemberApplicationDatas() {
        getMemberApplicationData({ ContactId: this.contactID})
            .then(result => {
                if (result) {
                    this.resultData = result.lstMember;
                   /* console.log('result : '+JSON.stringify(result));
                    console.log('this.resultData: new ' + JSON.stringify(this.resultData));
                    this.Profileimage = result.memImgURL;
                    console.log('profile image '+this.Profileimage); */
                    result.lstMember.forEach(el => {
                        console.log(el);
                        this.memberId = el.Id;
                        console.log('memberId-->' + this.memberId);
                        this.date = el.CreatedDate
                        this.firstName = el.Name;
                        this.lastName = el.Last_Name__c;
                        this.salutation = el.Contact__r.Salutation;
                        this.userEmail = el.Email_ID__c;
                        this.expiryDate = el.Expiry_Date__c;
                        this.autoGenMemId = el.Member_Id__c;
                        // this.Interest=el.Interests__c;
                        // this.DOB=e1.Date_of_Birth__c;
                        this.country = el.Country__c;
                        let date = new Date(this.expiryDate);
                        const dtf = new Intl.DateTimeFormat('en', {
                            year: 'numeric',
                            month: 'numeric',
                            day: '2-digit'
                            });
                        const [{value: mo}, , {value: da}, , {value: ye}] = dtf.formatToParts(date);
                        this.expiryDate = `${da}/${mo}/${ye}`;
                        
                        const qrCodeGenerated = new qrcode(0, 'H');
                        var strForGenearationOfQRCode = `https://tacd-dev-ed.develop.my.site.com/TheArtsClub/s/event-visit?C__MemberId=${this.memberId}`;
                        //var strForGenearationOfQRCode = `https://theartsclub-dev-ed.develop.my.site.com/s/visit?C__MemberId=${this.memberId}`;
                        //var strForGenearationOfQRCode = `https://theartsclub-dev-ed.develop.lightning.force.com/lightning/n/MemberLogin?C__Id=${this.recordId}&C__firstName=${this.firstname}&C__lastName=${this.lastname}&C__Salutation=${this.salutation}&C__MemberId=${this.memberid}`;
                        console.log('settttt' + strForGenearationOfQRCode)
                        qrCodeGenerated.addData(strForGenearationOfQRCode);
                        qrCodeGenerated.make();
                        let element = this.template.querySelector(".qrcode2");
                        element.innerHTML = qrCodeGenerated.createSvgTag({});
                    });
                    //this.url = `lightning/n/MemberLogin?C__Id=${this.contactID}&C__firstName=${this.firstName}&C__lastName=${this.lastName}&C__Salutation=${this.salutation}`
                    //console.log('In for url' + this.url)
                }
            })
            .catch(error => {
                console.log('error--->', error)
            });
    }
    onShowQr(event){
        this.showQrCode = true;
        let device = event.currentTarget.dataset.id;
        console.log('device--->', JSON.stringify(device))

        if(device == 'android'){
            this.showWalletButton = true;
            this.buttonLabel = 'Add to google wallet';
        }else{
            this.showWalletButton = true;
            this.buttonLabel = 'Add to apple wallet';
        }
    }
//     get Profileimage() {
//         if (this.memberId == 'a005h00000ovFArAAM'){
//               return Rehan_Picture;
//         }
//         else if (this.memberId == 'a005h00000ovFG3AAM'){
//             return Amin_picture;
//         } else if(this.country == 'Dubai') {
//             return Dubai_Profile;
//         }else {
//             return Profile_Picture;
//         }
//     }
    get artClubLogo() {
        return artClubImages + '/art_club_images/logo.jpg';
    }

    get yashLogo() {
        return YashClubManagement + '/YashClubManagement/YASH.png';
    }

    get adroidLogo(){
        return artsclubDeviceLogos + '/artsClubDeviceLogo/android-logo.png';
    }
    get iosLogo(){
        return artsclubDeviceLogos + '/artsClubDeviceLogo/png-apple-logo-9711.png';
    }
    handleClickWallet(){
        this.showSpinner = true;
        getGoogleWalletDetails({ email : this.userEmail ,country:this.userCountry})
        .then(result=>{
            console.log('result--->', JSON.stringify(result))
            if(result){
                 this.showSpinner = false;

                this[NavigationMixin.Navigate]({
                    "type": "standard__webPage",
                    "attributes": {
                        "url": `${result}`
                    }
                });
            }
        })
        .catch(error =>{
            console.log('error--->', JSON.stringify(error))
            this.showSpinner = false;
        })
    }
}