import { LightningElement,api,wire } from 'lwc';
import getRecordsDetails from '@salesforce/apex/MemberEventsDirectory.getRecordsDetails';
export default class EventDetails extends LightningElement {
   @api recordId='a035h00000bDAoNAAW';
   @wire(getRecordsDetails, {eventId:'$recordId'}) eventdata;

}