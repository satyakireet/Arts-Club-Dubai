import {LightningElement } from 'lwc';

export default class IFrame extends LightningElement {
  
  
}