import { LightningElement,api } from 'lwc';
import getContactDetails from '@salesforce/apex/profileCardHandler.getContactDetails';
import getUserDetails from '@salesforce/apex/profileCardHandler.getUserDetails';
import bannerIamges from '@salesforce/resourceUrl/bannerIamges';
import Profile_Picture from '@salesforce/resourceUrl/Profile_Picture';
import YASHProfile_Picture from '@salesforce/resourceUrl/profile';

export default class ProfileCard extends LightningElement {

    @api recordId;
    contactid;
    //profilePicUrl=Profile_Picture;
    profilePicUrl=YASHProfile_Picture;
    bannerUrl;
    contactName;
    salutation;
 
    get bannerImages(){
        return bannerIamges +'/bannerimage/banner.png'
    }
    // get profilePicUrl(){
    //     return Profile_Picture
    // }

    connectedCallback(){
        // window.alert("case id:"+JSON.stringify(this.recordId));
        getContactDetails({ caseId : this.recordId})
        .then(result=>{
            // window.alert("case details:"+JSON.stringify(result));
            this.contactid = result[0].ContactId;
            // window.alert("case details:"+JSON.stringify(result[0].ContactId));
            this.salutation = result[0].Contact.Salutation;
            this.contactName = result[0].Contact.Name;
            if(this.contactid != null){
                console.log("this.contactid:"+JSON.stringify(this.contactid));
                console.log("this.salutation:"+JSON.stringify(this.salutation));
                console.log("this.contactName:"+JSON.stringify(this.contactName));

                this.userDetailsCall(this.contactid);
            }
        })
        .catch(error =>{
            console.log("case error:"+JSON.stringify(error));

        })
    }

    // userDetailsCall(contactid){

    //     getUserDetails({ conId : contactid})
    //     .then(result=>{
    //         this.profilePicUrl = result[0].MediumPhotoUrl;
    //         console.log("profilePicUrl details:"+JSON.stringify(this.profilePicUrl));
    //         this.bannerUrl = result[0].MediumBannerPhotoUrl;
    //     })
    //     .catch(error =>{
    //         console.log("user error:"+JSON.stringify(error));

    //     })
    // }
}