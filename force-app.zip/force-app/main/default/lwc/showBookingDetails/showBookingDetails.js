import { LightningElement,track } from 'lwc';
import getBookings from '@salesforce/apex/customBookingRecord.getBookings';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import Id from '@salesforce/user/Id';
export default class ShowBookingDetails extends LightningElement {

    connectedCallback(){
        this.getBookingList();
    }
    
    bookingList;
    error;
    isModalOpen = false;
    keyIndex = 0;
    selectedCardId;
    @track userId = Id;
    @track itemList = [{
        id: 0
    }];

    getBookingList(){
        console.log('userId==='+this.userId);
        getBookings({userId:this.userId})
        .then(data => {
            console.log('data======>'+JSON.stringify(data))
            let currentData = [];
            data.forEach(row => {
                let rowData = {};
                rowData.Id = row.Id;
                rowData.Name = row.Name;
                rowData.guestNumber = row.No_Of_Guests__c;
                rowData.checkIn = row.Check_In__c;
                rowData.checkOut = row.Check_Out__c;
                console.log('row.Check_Out__c=========>'+row.Check_Out__c)
                if(row.Check_Out__c === '' || row.Check_Out__c === null || row.Check_Out__c === undefined){
                    rowData.showButton = true;
                }else{
                    rowData.showButton = false;
                }    
                if(row.Member_Events__c){                       
                    rowData.memberEventName = row.Member_Events__r.Name;
                    rowData.imageUrl = row.Member_Events__r.Event_Image_URL__c;
                }   
                
                currentData.push(rowData);
            });
            this.bookingList = currentData;           
            console.log('bookingList======'+JSON.stringify(this.bookingList))
        })
            .catch((error) => {
                this.error = error;
                this.bookingList = undefined;
                console.log('error======'+JSON.stringify(this.error))
            });
    }

    handleAddGuestClick(event){
        this.selectedCardId = event.target.dataset.id
        this.isModalOpen = true;  
    }

    closeModal() {
        // to close modal set isModalOpen tarck value as false
        this.isModalOpen = false;
    }

    addRow() {
        ++this.keyIndex;
        var newItem = [{ id: this.keyIndex }];
        this.itemList = this.itemList.concat(newItem);
    }

    removeRow(event) {
        if (this.itemList.length >= 2) {
            this.itemList = this.itemList.filter(function(element) {
                return parseInt(element.id) !== parseInt(event.target.accessKey);
            });
        }
    }

    handleSubmit(event) {
        this.template.querySelectorAll('lightning-record-edit-form').forEach(element => {
            element.submit();
        });
        this.closeModal()
    }   
    
    showToastMessage() {
        const evt = new ShowToastEvent({
            title: 'Success',
            message: 'Guest Added Sucessfully',
            variant: 'success',
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);
    }
}