import { LightningElement,api,wire } from 'lwc';
import { createRecord } from 'lightning/uiRecordApi';
import MEMBER_APP_OBJECT from '@salesforce/schema/Mem__c';
import TITLE_OBJECT from '@salesforce/schema/Mem__c.Title__c';
import LASTNAME_OBJECT from '@salesforce/schema/Mem__c.Last_Name__c';
import FIRSTNAME_OBJECT from '@salesforce/schema/Mem__c.Name';
import EMAIL_OBJECT from '@salesforce/schema/Mem__c.Email_ID__c';
import NATIONALITY_OBJECT from '@salesforce/schema/Mem__c.Nationality__c';
import DOB_OBJECT from '@salesforce/schema/Mem__c.Date_of_Birth__c';
import PHONE_OBJECT from '@salesforce/schema/Mem__c.Phone_Number__c';
import MOBILE_OBJECT from '@salesforce/schema/Mem__c.Mobile__c';
import POBOX_OBJECT from '@salesforce/schema/Mem__c.PO_Box__c';
import SPOUSENAME_OBJECT from '@salesforce/schema/Mem__c.Name_of_Spouse__c';
import OTHER_CLUB_OBJECT from '@salesforce/schema/Mem__c.Other_Clubs__c';
import VISITED_DUBAI_CHECKBOX_OBJECT from '@salesforce/schema/Mem__c.Previously_Visited_The_Arts_Club_Dubai__c';


export default class UserSignUpPage extends LightningElement {

    otherRecordId;

    title;
    lastName;
    nationality;
    firstName;
    email;
    preferredName;
    dataOfBirth;
    phone;
    mobile;
    poBox;
    nameOfSpouse;
    visitedToDubaiCheckbox=false;
    otherClub;

    handleChange(event){

        const fieldApi = event.currentTarget.dataset.id;
        console.log('fieldApi--->', JSON.stringify(fieldApi))

        if(fieldApi == 'Title__c'){
            this.title = event.target.value;
        }
        else if(fieldApi == 'lastname'){
            this.lastName = event.target.value;
        }

        else if(fieldApi == 'firstName'){
            this.firstName = event.target.value;
        }

        else if(fieldApi == 'email'){
            this.email = event.target.value;
        }

        else if(fieldApi == 'nationality'){
            this.nationality = event.target.value;
        }

        else if(fieldApi == 'preferredName'){
            this.preferredName = event.target.value;
        }

        else if(fieldApi == 'dataOfBirth'){
            this.dataOfBirth = event.target.value;
        }

        else if(fieldApi == 'phone'){
            this.phone = event.target.value;
        }

        else if(fieldApi == 'mobile'){
            this.mobile = event.target.value;
        }

        else if(fieldApi == 'poBox'){
            this.poBox = event.target.value;
        }

        else if(fieldApi == 'nameOfSpouse'){
            this.nameOfSpouse = event.target.value;
        }

        else if(fieldApi == 'otherClub'){
            this.otherClub = event.target.value;
        }

        else if(fieldApi == 'visitedToDubaiCheckbox'){
            this.visitedToDubaiCheckbox = event.target.checked;
        }
    }



    createApplication(){
        const fields = {};

        fields[TITLE_OBJECT.fieldApiName] = this.title;
        fields[LASTNAME_OBJECT.fieldApiName] = this.lastName;
        fields[FIRSTNAME_OBJECT.fieldApiName] = this.firstName;
        fields[EMAIL_OBJECT.fieldApiName] = this.email;
        // fields[NATIONALITY_OBJECT.fieldApiName] = this.nationality;
        // fields[DOB_OBJECT.fieldApiName] = this.dataOfBirth;
        // fields[PHONE_OBJECT.fieldApiName] = this.phone;
        // fields[MOBILE_OBJECT.fieldApiName] = this.mobile;
        // fields[POBOX_OBJECT.fieldApiName] = this.poBox;
        // fields[SPOUSENAME_OBJECT.fieldApiName] = this.nameOfSpouse;
        // fields[OTHER_CLUB_OBJECT.fieldApiName] = this.otherClub;
        // fields[VISITED_DUBAI_CHECKBOX_OBJECT.fieldApiName] = this.visitedToDubaiCheckbox;


        const recordInput = {
            apiName: MEMBER_APP_OBJECT.objectApiName,
            fields: fields
          };

        createRecord(recordInput)
        .then((record) => {
            localStorage.setItem('id', record.id);
            console.log('record data'+JSON.stringify(record));
            this.otherRecordId = record.id;
            
            console.log('record data id'+JSON.stringify(this.otherRecordId));
            if(this.otherRecordId){
                this.handleFileUpload(this.otherRecordId);
            }

          })
        .catch(error =>{
            console.log('error new'+JSON.stringify(error));
        })
    }

    handleFileUpload(otherRecordId){
        this.template.querySelector('c-file-uploader').handleClick(otherRecordId);
    }

    


}