import { LightningElement } from 'lwc';
export default class BookingFormPage extends LightningElement {

}