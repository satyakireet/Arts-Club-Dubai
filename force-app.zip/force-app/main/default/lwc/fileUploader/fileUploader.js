import { LightningElement,api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import uploadFile from '@salesforce/apex/FileUploaderController.uploadFile';

export default class FileUploader extends LightningElement {

    @api recordId;
    fileData;

    get acceptedFormats() {
        return ['.pdf', '.png', '.jpg'];
    }

    connectedCallback(){
        console.log('recordId: ' +this.recordId);
    }

    openfileUpload(event) {
        const file = event.target.files[0]
        var reader = new FileReader()
        reader.onload = () => {
            var base64 = reader.result.split(',')[1]
            this.fileData = {
                'filename': file.name,
                'base64': base64,
                'recordId': this.recordId
            }
            console.log(this.fileData)
        }
        reader.readAsDataURL(file)
    }

    @api handleClick(OtherRecordId){
        console.log('parent record id:'+JSON.stringify(OtherRecordId))

        const {base64, filename, recordId} = this.fileData
        uploadFile({ base64, filename, recordId:OtherRecordId }).then(result=>{
            this.fileData = null
            let title = `${filename} uploaded successfully!!`
            this.toast(title)
        })
        .catch(error =>{
            console.log('error file'+JSON.stringify(error));
        })
    }

    toast(title){
        const toastEvent = new ShowToastEvent({
            title, 
            variant:"success"
        })
        this.dispatchEvent(toastEvent)
    }
}