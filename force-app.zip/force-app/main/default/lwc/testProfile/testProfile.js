import { LightningElement } from 'lwc';
export default class TestProfile extends LightningElement {
    profilePicUrl = 'https://theartsclub-dev-ed.develop.file.force.com/sfc/servlet.shepherd/version/download/0685h00000K30BS';
}