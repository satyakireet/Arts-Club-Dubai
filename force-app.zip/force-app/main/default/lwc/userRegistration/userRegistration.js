import { LightningElement } from 'lwc';
import ArtsClub from '@salesforce/resourceUrl/ArtsClubImage';


export default class UserRegistration extends LightningElement {

    artsClubimage =ArtsClub;
}