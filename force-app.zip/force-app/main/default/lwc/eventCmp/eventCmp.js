import { LightningElement, api,track } from 'lwc';
import getRecordsDetails from '@salesforce/apex/MemberEventsDirectory.getRecordsDetails';

export default class EventCmp extends LightningElement {
     @api eventName;
     @api Name;
    @api eventLocation;
    @api eventIcon;
    @api eventTitle;
    @api initialCounter = 1;
    @api Description__c;
    @api unitPrice = 238.10;
    @track getdetails; 
    totalPrice=0;
    evId='';
    counter=1;
    @api recordId;


    handleIncrement() {
        console.log('Handle Inside');
        this.counter++;
        console.log(this.counter);
        console.log('UnitPrice-->'+this.unitPrice);
        this.totalPrice = this.unitPrice* this.counter;
        console.log(this.totalPrice);

    }

    handleDecrement() {
        if (this.counter > 1) {
            this.counter--;
            this.totalPrice = this.unitPrice * this.counter;
        }
    }
  
    mapMarkers = [
    {
        location: {
            City: 'Dubai',
            Country: 'UAE'
        },
        icon: 'custom:custom26',
        title: 'asd'
    }
];

    markersTitle = 'Accounts';
    zoomLevel = 4;

    connectedCallback() {
        //code
        console.log('testinside'+window.location);
        let urlValue = window.location.toString().split('/');
        console.log('Arr -> '+JSON.stringify(urlValue));
        console.log('EventId -> '+urlValue[urlValue.length-2]);
        let eveId = urlValue[urlValue.length-2];
        getRecordsDetails({eventId:eveId}).then(result => {
            this.getdetails=result;
            console.log('GetDetails-->'+JSON.stringify(this.getdetails));
            //this.unitPrice = this.getdetails[0].Event_Price__c; 
            this.totalPrice = this.unitPrice*this.counter;
        }).catch(error => { 
            this.error= error;
        });
    }

   handleClick() {
        const eventDetail = {
            eventName: this.eventName,
            counter: this.counter,
            totalPrice: this.totalPrice
        };
        const event = new CustomEvent("guestfromchildcmp", { detail: eventDetail });
        this.dispatchEvent(event);
    }
  
}