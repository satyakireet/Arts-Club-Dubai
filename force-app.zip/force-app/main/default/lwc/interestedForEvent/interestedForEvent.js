import { LightningElement } from 'lwc';
export default class InterestedForEvent extends LightningElement {

}