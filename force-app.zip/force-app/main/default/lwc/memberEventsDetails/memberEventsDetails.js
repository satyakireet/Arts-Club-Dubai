import { LightningElement,track } from 'lwc';
import Member_Event from '@salesforce/schema/Member_Event__c';

export default class MemberEventsDetails extends LightningElement {
   // @track fields=[Location,Date,Time,Type,Description,Price,Status];
    objectApiName= Member_Event;
    recordId='a035h00000bDAoNAAW';

}