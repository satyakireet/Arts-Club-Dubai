import { LightningElement } from 'lwc';
export default class TestSurvey extends LightningElement {

}