import { LightningElement,api } from 'lwc';

import ArtsClub from '@salesforce/resourceUrl/ArtsClubImage';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import uploadFile from '@salesforce/apex/FileUploaderClass.uploadFile';

export default class RegistrationPage extends LightningElement {

    artsClubimage =ArtsClub;
    file;
    OtherRecordId;
    fileData;


    get acceptedFormats() {
        return ['.pdf', '.png'];
    }

    submitHandler(event){
        this.OtherRecordId = event.detail.id;
        console.log('OtherRecordId:'+JSON.stringify(this.OtherRecordId));

        if(this.OtherRecordId){
            this.handleFileUpload(this.OtherRecordId);
        }

        console.log('In submit handler 11');

       const info1 = this.template.querySelectorAll(".checkboxes");
       const info2 = this.template.querySelectorAll(".customCheckbox");
       //const info3 =this.template.querySelector("lightning-input-field[data-id = 'reqField']");
       let allCheckBoxValue1;
       let allCheckBoxValue2;
      
       Array.from(info1).forEach((element)=> {
          // console.log(element.checked);
           if(element.checked == false){
            allCheckBoxValue1 =false;
           }
       })

       Array.from(info2).forEach((element)=> {
        // console.log(element.checked);
         if(element.checked == false){
          allCheckBoxValue2 =false;
         }
     })

        
        if(allCheckBoxValue1 == false || allCheckBoxValue2 == false){
            const evt = new ShowToastEvent({
                title :'Error',
                message: 'Plese check all required checkbox',
                variant:'error'
            });
            this.dispatchEvent(evt);

            event.preventDefault();
        }

    }

    handleSuccess(event){

        this.OtherRecordId = event.detail.id;
        console.log('OtherRecordId:'+JSON.stringify(this.OtherRecordId));

        if(this.OtherRecordId){
            this.handleFileUpload(this.OtherRecordId);
        }

        console.log('Handler Method before call');
       // this.handlerMethod();
        console.log('Handler Method after call');
       
        const evt = new ShowToastEvent({
            title :'Application Saved',
            message: 'Thanks for reaching out! Your form Submit Succesfully and Our team will get back to you in sometime',
            variant:'success'
        });
        this.dispatchEvent(evt);  

        //this.handlerMethod();
    }

    handleFileUpload(OtherRecordId){
        this.template.querySelector('c-file-uploader').handleClick(OtherRecordId);
    }

    
    errorHandler(event){
        console.log('error::'+JSON.stringify(event.detail));
       
        // if(event.detail.message == 'The requested resource does not exist'){
            const evt = new ShowToastEvent({
                title :'Application Failed to Save',
                message: event.detail.message,
                variant:'error'
            });
            this.dispatchEvent(evt);
        // } 

        /*
            const evt = new ShowToastEvent({
                title :'Error while submitting the data',
                message: event.detail.message,
                variant:'error',
                mode:'sticky'
            });
            this.dispatchEvent(evt);
            */
        
    }

    // File Upload

    /*
      
        openfileUpload(event) {
        this.file = event.target.files[0];
       
    }

    handlerMethod(){

        if(this.OtherRecordId){

            var reader = new FileReader()
            reader.onload = () => {
                var base64 = reader.result.split(',')[1]
                this.fileData = {
                    'filename': this.file.name,
                    'base64': base64,
                    'recordId': this.OtherRecordId
                }
            }
            
            console.log(this.file);
            console.log(this.fileData);
            reader.readAsDataURL(this.file)

        const {base64, filename, recordId} = this.fileData
        uploadFile({ base64, filename, recordId }).then(result=>{
            this.fileData = null
            let title = `${filename} uploaded successfully!!`
            this.toast(title)
        })
        
        }
    }

    toast(title){
        const toastEvent = new ShowToastEvent({
            title, 
            variant:"success"
        })
        this.dispatchEvent(toastEvent)
    }


    */

    
}