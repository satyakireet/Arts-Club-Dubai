import { LightningElement, wire, api } from 'lwc';
import getMemberEventData from '@salesforce/apex/EventCardController.getMemberEventData';
import getBookingDetails from '@salesforce/apex/EventCardController.getBookingDetails';

const columns = [{
        label: 'Member Name',
        fieldName: 'BookingURL',
        type: 'url',
        typeAttributes: {
            label: {
                fieldName: 'MemberName'
            }
        }
    },
    // { label: 'Member Events', fieldName: 'EventName' },
    // { label: 'No of Guests', fieldName: 'NumberOfGuests' },
    { label: 'Check In', fieldName: 'CheckIn' },
    { label: 'Check Out', fieldName: 'CheckOut' },
];

export default class HomePageEventsAndBookingsListView extends LightningElement {
    eventData = []
    selectedEvent
    BookingData = []
    showDataTable = false
    columns = columns;
    connectedCallback() {
        this.getMemberEventDetails()
    }
    getMemberEventDetails() {
        getMemberEventData()
            .then(result => {
                if (result) {
                    let tempArray = []
                    result.forEach(element => {
                        let temp = {}
                        temp.label = element.Name;
                        temp.value = element.Id;
                        tempArray.push(temp)
                    });
                    this.eventData = tempArray
                    console.log('this.eventData:' + JSON.stringify(this.eventData))
                }
            })
            .catch(error => {
                console.log('error--->', error)
            });
    }
    handleEventChange(event) {
        console.log('value-->' + event.target.value)
        this.selectedEvent = event.target.value

        getBookingDetails({ eventId: this.selectedEvent })
            .then(result => {
                if (result) {
                    this.showDataTable = true
                    let tempArray = []
                    result.forEach(element => {
                        let temp = {}
                        temp.Id = element.Id;
                        temp.Name = element.Name;
                        temp.MemberName = element.User__r.Name;
                        temp.NumberOfGuests = element.No_Of_Guests__c;
                        temp.EventName = element.Member_Events__r.Name;
                        temp.CheckOut = element.Check_Out__c;
                        temp.CheckIn = element.Check_In__c;
                        temp.BookingURL = `https://theartsclub-dev-ed.develop.lightning.force.com/lightning/r/Booking__c/${element.Id}/view`
                        tempArray.push(temp)
                    });
                    this.BookingData = tempArray
                    console.log('this.BookingData:' + JSON.stringify(this.BookingData))
                    if (this.BookingData.length === 0) {
                        this.showDataTable = false
                    } else {
                        this.showDataTable = true
                    }

                }
            })
            .catch(error => {
                console.log('error--->', error)
            });


    }

}