import { LightningElement,api } from 'lwc';
import artsClubVideo from '@salesforce/resourceUrl/artsClubVideo';


export default class Hero extends LightningElement {

    @api video;
    @api image

    videos = 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4';


    get isVideo() {
        // if(this.video){
        //     return this.video;
        // }else{
            return artsClubVideo + '/art_club_images/heroVideo.mp4';
        // }
    }

    get isImg() {
        return artsClubVideo + '/art_club_images/heroImage.jpeg';
    }
}