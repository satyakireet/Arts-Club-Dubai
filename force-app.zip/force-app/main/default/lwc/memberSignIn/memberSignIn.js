import { LightningElement,wire,track,api } from 'lwc';

import Id from '@salesforce/user/Id';
import { getRecord } from 'lightning/uiRecordApi'
import ArtsClub from '@salesforce/resourceUrl/ArtsClubLogoImage';
import firstTemplate from './memberSignIn.html'
import secondTemplate from './memberSignInSecondTemplate.html';
import doLogin from '@salesforce/apex/CommunityLoginController.doLogin';

import getRecordsDetails from '@salesforce/apex/MemberEventsDirectory.getRecordsDetails';



export default class MemberSignIn extends LightningElement {
    recordId='a035h00000csnHtAAI';
   @wire(getRecordsDetails, {eventId:'$recordId'}) eventdata;

    memberLoggedIn = false;
    userId = Id; 
    artsClubimage =ArtsClub;
    isRender = false;

    

    render(){
        if(this.isRender == false){
            return firstTemplate;
           // console.log($memberLoggedIn);
        }
        else if(this.isRender == true){
            return secondTemplate;  
        }
    }
    
    @wire(getRecord,{recordId:'$userId',fields:['User.Name']})
		getUserRecord({data,error}){
			console.log('Wire Method Called');
			
			if(data){
				console.log(data);
				if(data.fields.Name.value){
                    
                    this.memberLoggedIn = true
                    console.log(this.memberLoggedIn);
                }


			}

			if(error){
				console.log(error.message);
			}
		   
		} 

        handleLoginTemplate(){
            this.isRender = true;
        }

        username;
        password;
        error;
        @track errorCheck;
        @track errorMessage;
    
        handleUserNameChange(event){
    
            this.username = event.target.value;
            console.log( this.username);
        }
    
        handlePasswordChange(event){
            
            this.password = event.target.value;
            console.log( this.password);
        }

        connectedCallback(){

            var meta = document.createElement("meta");
            meta.setAttribute("name", "viewport");
            meta.setAttribute("content", "width=device-width, initial-scale=1.0");
            document.getElementsByTagName('head')[0].appendChild(meta);
        }
    
        handleLogin(event){
    
           if(this.username && this.password){
           this.memberLoggedIn = true;
            this.isRender == false ;
            
    
           event.preventDefault();
           doLogin({ username: this.username, password: this.password })
           .then(result => {

            console.log('Success');
               
               console.log('Success'+result);
            //    this.memberLoggedIn = true;
            // this.isRender == false ;
           })
           .catch(error => {
            console.log('Error - '+error);
            console.log('Error - '+error);
               this.error = error;      
               this.errorCheck = true;
               this.errorMessage = error.body.message;
           });
            
            }
    
        }
}