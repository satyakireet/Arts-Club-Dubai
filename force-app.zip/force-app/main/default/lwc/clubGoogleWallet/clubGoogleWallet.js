import { LightningElement } from 'lwc';
const serviceAccountFile = '/path/to/key.json';
const issuerId = '3388000000022179156';
const classId = '3388000000022179156.0defba34-0250-4792-aa52-10a4c273e7ee';

export default class ClubGoogleWallet extends LightningElement {

  callGoogleWallet() {
    createPassAndToken();
  }

  async createPassAndToken(req, res) {
    const credentials = require(serviceAccountFile);
    const httpClient = new GoogleAuth({
      credentials: credentials,
      scopes: 'https://www.googleapis.com/auth/wallet_object.issuer'
    });

    let newObject = {
      'id': `${issuerId}.${objectSuffix}`,
      'classId': `${issuerId}.${classSuffix}`,
      'state': 'ACTIVE',
      'heroImage': {
        'sourceUri': {
          'uri': 'https://farm4.staticflickr.com/3723/11177041115_6e6a3b6f49_o.jpg'
        },
        'contentDescription': {
          'defaultValue': {
            'language': 'en-US',
            'value': 'Hero image description'
          }
        }
      },
      'textModulesData': [
        {
          'header': 'Text module header',
          'body': 'Text module body',
          'id': 'TEXT_MODULE_ID'
        }
      ],
      'linksModuleData': {
        'uris': [
          {
            'uri': 'http://maps.google.com/',
            'description': 'Link module URI description',
            'id': 'LINK_MODULE_URI_ID'
          },
          {
            'uri': 'tel:6505555555',
            'description': 'Link module tel description',
            'id': 'LINK_MODULE_TEL_ID'
          }
        ]
      },
      'imageModulesData': [
        {
          'mainImage': {
            'sourceUri': {
              'uri': 'http://farm4.staticflickr.com/3738/12440799783_3dc3c20606_b.jpg'
            },
            'contentDescription': {
              'defaultValue': {
                'language': 'en-US',
                'value': 'Image module description'
              }
            }
          },
          'id': 'IMAGE_MODULE_ID'
        }
      ],
      'barcode': {
        'type': 'QR_CODE',
        'value': 'QR code'
      },
      'cardTitle': {
        'defaultValue': {
          'language': 'en-US',
          'value': 'Generic card title'
        }
      },
      'header': {
        'defaultValue': {
          'language': 'en-US',
          'value': 'Generic header'
        }
      },
      'hexBackgroundColor': '#4285f4',
      'logo': {
        'sourceUri': {
          'uri': 'https://storage.googleapis.com/wallet-lab-tools-codelab-artifacts-public/pass_google_logo.jpg'
        },
        'contentDescription': {
          'defaultValue': {
            'language': 'en-US',
            'value': 'Generic card logo'
          }
        }
      }
    };
  
    const objectUrl = 'https://walletobjects.googleapis.com/walletobjects/v1/genericObject/';
    const objectPayload = newObject;
  
    objectPayload.id = `${issuerId}.${req.body.email.replace(/[^\w.-]/g, '_')}-${classId}`;
    objectPayload.classId = `${issuerId}.${classId}`;
  
    let objectResponse;
    try {
      objectResponse = await httpClient.request({url: objectUrl + objectPayload.id, method: 'GET'});
      console.log('existing object', objectPayload.id);
    } catch (err) {
      if (err.response && err.response.status === 404) {
        objectResponse = await httpClient.request({url: objectUrl, method: 'POST', data: objectPayload});
        console.log('new object', objectPayload.id);
      } else {
        console.error(err);
        throw err;
      }
    }
  
    res.send("Form submitted!");
  }
}