import { LightningElement } from 'lwc';
export default class SurveyIframe extends LightningElement {

}