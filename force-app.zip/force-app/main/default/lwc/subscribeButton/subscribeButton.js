import { LightningElement,api,track,wire } from 'lwc';
import { getRecord, updateRecord,getFieldValue } from 'lightning/uiRecordApi';
import USER_ID from '@salesforce/user/Id';
import ID_FIELD from '@salesforce/schema/Contact.Id';
import CONTACT_ID from "@salesforce/schema/User.ContactId";
import CONTACT_OBJECT from '@salesforce/schema/Contact';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import OPT_IN_USER_FIELD from '@salesforce/schema/Contact.Opt_in__c';

export default class SubscribeButton extends LightningElement {
    @api recordId;
    @track hidebutton=true;
    ISoptin;
    conid=CONTACT_ID;
    @wire(getRecord, { recordId: USER_ID, fields: [CONTACT_ID] })
    user;

    get contactId() {
        return getFieldValue(this.user.data,CONTACT_ID);
      }
     
        // get isOptedIn() {
        //      return  getFieldValue (this.user.data.fields.Opt_in__c.value);
        //           }


                  @wire(getRecord,{recordId: '$contactId',fields:['Contact.Opt_in__c']})
                  getAccountRecord(response){
                   console.log('Wire Method Called'+this.contactId);
                  
                  if(response.data){
                   console.log('test');
                   console.log(response.data.fields.Opt_in__c.value);
                                 
                                  this.ISoptin=response.data.fields.Opt_in__c.value;
                                 
                 
                   }
                       if(response.error)
                       {
                  console.log('test2');
                  console.log(response.error);
                  }
                  
                  }
                  
        
    updateContact() {
        // const fields = {};
        // fields[IS_SITE_USER_FIELD.fieldApiName] = true;
        //  console.log('test');
         
         const fields = {};
       
            console.log('conid'+this.contactId);
            // console.log('optin=='+this.isOptedIn);
            fields[ID_FIELD.fieldApiName] = this.contactId;
           fields[OPT_IN_USER_FIELD.fieldApiName] = true;
      
            const recordInput = { fields };
            this.hidebutton=false;

            updateRecord(recordInput)
                .then(() => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Contact updated',
                            variant: 'success'
                        })
                    );
                   
                })
                .catch(error => {
                    console.log("error"+JSON.stringify(error));
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error creating record',
                            message: error.body.message,
                            variant: 'error'
                            
                        })
                        
                    );
                });
    }
}