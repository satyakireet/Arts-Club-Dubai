import { LightningElement,api,wire } from 'lwc';
import Profile_Picture from '@salesforce/resourceUrl/Profile_Picture';
import Membership from '@salesforce/resourceUrl/Membership';
import {CurrentPageReference} from 'lightning/navigation'
import artClubImages from '@salesforce/resourceUrl/artClubImages';
import ArtsClubLogoImage from '@salesforce/resourceUrl/ArtsClubLogoImage';
export default class Test extends LightningElement {
    values
    artsClubImage =ArtsClubLogoImage;
    confirstName
    conlastName
    salutation

    contactExist =false;
    contactId;

    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        this.values = JSON.stringify(currentPageReference);
      if (currentPageReference) {
        //console.log(currentPageReference);
        const urlValue = currentPageReference.state.C__Id;
        
        if (urlValue) {
          this.contactExist = true;
         this.confirstName = currentPageReference.state.C__firstName;
         this.conlastName = currentPageReference.state.C__lastName;
         this.salutation = currentPageReference.state.C__Salutation;
            console.log('urlValue',urlValue);
            console.log(urlValue);
            
        } else {
            this.contactExist = false;
        }
      }
    }
    get Profileimage() {
      return Profile_Picture;
  }
  get MembershipImage() {
      return Membership;
  }

}