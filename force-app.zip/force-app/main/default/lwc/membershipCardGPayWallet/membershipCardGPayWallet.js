import { LightningElement, wire, api } from 'lwc';
import Profile_Picture from '@salesforce/resourceUrl/DavidProfile';
import artClubImages from '@salesforce/resourceUrl/artClubImages';
import USER_ID from '@salesforce/user/Id';
import CONTACT_ID from '@salesforce/schema/User.ContactId';
import USER_CITY from '@salesforce/schema/User.City';
import USER_PIC from '@salesforce/schema/User.SmallPhotoUrl';
import { getRecord } from 'lightning/uiRecordApi';
import artsclubDeviceLogos from '@salesforce/resourceUrl/artsclubDeviceLogos';
import getMemberApplicationData from '@salesforce/apex/EventCardController.getMemberApplicationData'
import qrcode from './qrcode.js';
import getGoogleWalletDetails from '@salesforce/apex/GoogleWalletHandler.getGoogleWalletDetails';
import { NavigationMixin } from 'lightning/navigation';
import getProfile from '@salesforce/apex/EventCardController.getUserProfilePhoto';


export default class MembershipCardGPayWallet extends NavigationMixin(LightningElement) {
    
    contactID
    resultData = []
    url
    @api recordId
    name
    date
    firstName
    lastName
    salutation;
    buttonLabel = 'Add to google wallet';
    showQrCode=false;
    showWalletButton = false;
    memberId;
    showSpinner = false;
    userCountry;
    userImage;
    userEmail;
    profilePicUrl;
    expiryDate;
    
    @wire(getRecord, { recordId: USER_ID, fields: [CONTACT_ID,USER_CITY,USER_PIC] }) wireuser({ error, data }) {
        if (error) {
            console.log('error--->', error)
        } else if (data) {
            this.contactID = data.fields.ContactId.value;
            this.userCountry = data.fields.City.value;
            this.userImage = data.fields.SmallPhotoUrl.value;
            console.log('ContactId-->' + this.contactID)
            this.getMemberApplicationDatas()
        }
    }

    getMemberApplicationDatas() {
        getMemberApplicationData({ ContactId: this.contactID})
            .then(result => {
                if (result) {
                    this.resultData = result
                    console.log('this.resultData:' + JSON.stringify(this.resultData))

                    result.forEach(element => {
                        console.log(element)
                        this.date = element.CreatedDate
                        this.firstName = element.Name;
                        this.lastName = element.Last_Name__c;
                        this.salutation = element.Contact__r.Salutation;
                        this.memberId = element.Member_Id__c;
                        this.userEmail = element.Email_ID__c;
                        this.expiryDate = element.Expiry_Date__c;
                        let date = new Date(this.expiryDate);
                        const dtf = new Intl.DateTimeFormat('en', {
                            year: 'numeric',
                            month: 'numeric',
                            day: '2-digit'
                        });
                        const [{value: mo}, , {value: da}, , {value: ye}] = dtf.formatToParts(date);
                        this.expiryDate = `${da}/${mo}/${ye}`;
                        console.log('Date - '+this.expiryDate);
                    });
                    this.url = `lightning/n/MemberLogin?C__Id=${this.contactID}&C__firstName=${this.firstName}&C__lastName=${this.lastName}&C__Salutation=${this.salutation}`
                    console.log('In for url' + this.url)
                }
            })
            .catch(error => {
                console.log('error--->', error)
            });
            //this.Profileimage();
    }
    onShowQr(event){
        this.showQrCode = true;
        let device = event.currentTarget.dataset.id;
        console.log('device--->', JSON.stringify(device))

        if(device == 'android'){
            this.showWalletButton = true;
            this.buttonLabel = 'Add to google wallet';
        }else{
            this.showWalletButton = true;
            this.buttonLabel = 'Add to apple wallet';
        }
    }


    get Profileimage() {
        // getProfile({ memId: this.recordId }).then(result => {
        //     this.profilePicUrl = 'https://theartsclub-dev-ed.develop.file.force.com/sfc/servlet.shepherd/version/download/0685h00000K31VK';
        //     console.log('ProfileUrl - '+result[0].VersionDataUrl);
        //     //this.testUrl = result[0].VersionDataUrl;
        //     //this.profilePicUrl = result[0].VersionDataUrl;
        // }).catch(error => {
        //     console.log("user error:" + JSON.stringify(error));

        // });
        return Profile_Picture;
    }
    get artClubLogo() {
        return artClubImages + '/art_club_images/logo.jpg';
    }
    get adroidLogo(){
        return artsclubDeviceLogos + '/artsClubDeviceLogo/android-logo.png';
    }

    get iosLogo(){
        return artsclubDeviceLogos + '/artsClubDeviceLogo/png-apple-logo-9711.png';
    }

    handleClickWallet(){
        this.showSpinner = true;
        getGoogleWalletDetails({ email : this.userEmail ,country:this.userCountry})
        .then(result=>{
            console.log('result--->', JSON.stringify(result))
            if(result){
                 this.showSpinner = false;

                this[NavigationMixin.Navigate]({
                    "type": "standard__webPage",
                    "attributes": {
                        "url": `${result}`
                    }
                });
            }
        })
        .catch(error =>{
            console.log('error--->', JSON.stringify(error))
            this.showSpinner = false;
        })
    }
}