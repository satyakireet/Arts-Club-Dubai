import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class EventBooking extends LightningElement {
@api visible = false;
    handleAction(event){
        this.visible = true;
    }
    // handleSuccess(event) {
    //     console.log('Success',event.detail.id)
    //      const evt = new ShowToastEvent({
    //         title :'Record Save',
    //         message: 'Booking Made Successfully',
    //         variant:'success'
    //     });
        
    //     this.dispatchEvent(evt);
    // }
    // errorHandler(){
    //     const evt = new ShowToastEvent({
    //         title :'Error',
    //         message: 'Something went wrong, Please Contact your Administrator',
    //         variant:'error'
    //     });
        
    //     this.dispatchEvent(evt);
    // }
}