import { LightningElement, wire } from 'lwc';
import { getRecord } from 'lightning/uiRecordApi';
import USER_ID from '@salesforce/user/Id';
import CONTACT_ID from '@salesforce/schema/User.ContactId';
import getMemberEventData from '@salesforce/apex/EventCardController.getMemberEventData';
import { NavigationMixin } from 'lightning/navigation';

export default class EventCardPage extends NavigationMixin(LightningElement) {

    contactID
    resultData = [];

    @wire(getRecord, { recordId: USER_ID, fields: [CONTACT_ID] }) wireuser({ error, data }) {
        if (error) {
            console.log('error--->', error)
        } else if (data) {
            this.contactID = data.fields.ContactId.value;
            this.getMemberData()

        }
    }
    dayName = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    monthName = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    getMemberData() {
        getMemberEventData()
            .then(result => {
                if (result) {
                    // result.forEach(row => {
                    // })
                    console.log('Data--->', result)
                    this.resultData = result
                }
            })
            .catch(error => {
                console.log('error--->', error)
            });
    }
    recordData = {}
    handleOnClick(event) {
        //console.log('value-->' + event.target.value)
        console.log('DataID-->' + event.target.src)

        this.resultData.forEach(element => {
            if (element.Event_Image_URL__c == event.target.src) {
                this.recordData.Id = element.Id
                this.recordData.Description = element.Description__c;
                this.recordData.Location = element.Location__c;
                this.recordData.Price = element.Price__c;
                this.recordData.Name = element.Name;
                this.recordData.Date = element.Date__c;
                this.recordData.Time = element.Time__c;
                this.recordData.ImageUrl = element.Event_Image_URL__c;
            }
        });
        this[NavigationMixin.Navigate]({
            type: 'standard__namedPage',
            attributes: {
                pageName: 'event-detail',

            }
        });
        sessionStorage.setItem('recordData', JSON.stringify(this.recordData));
    }
    handleOnClickRead(event) {
        console.log('value-->' + event.target.value)

        this.resultData.forEach(element => {
            if (element.Event_Image_URL__c == event.target.value) {
                this.recordData.Id = element.Id
                this.recordData.Description = element.Description__c;
                this.recordData.Location = element.Location__c;
                this.recordData.Price = element.Price__c;
                this.recordData.Name = element.Name;
                this.recordData.Date = element.Date__c;
                this.recordData.Time = element.Time__c;
                this.recordData.ImageUrl = element.Event_Image_URL__c;
            }
        });
        this[NavigationMixin.Navigate]({
            type: 'standard__namedPage',
            attributes: {
                pageName: 'event-detail',

            }
        });
        sessionStorage.setItem('recordData', JSON.stringify(this.recordData));
    }
}