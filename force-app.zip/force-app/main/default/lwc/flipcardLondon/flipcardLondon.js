import { LightningElement, api, wire } from 'lwc';
import getRecords2 from '@salesforce/apex/MemberEventsDirectory.getRecords2';
import abcd from '@salesforce/resourceUrl/UpcomingEvents';
export default class FlipcardLondon extends LightningElement {
    imageUrl='abcd';
    @api recordId;
    showEvent=true;
    @api eveId;
    @wire(getRecords2) contactData;

    navigatetoDetails(event){
        this.showEvent=false;
        this.eveId=event.currentTarget.dataset.id;
        window.location.replace('https://theartsclub-dev-ed.develop.my.site.com/s/member-event/'+this.eveId)
        console.log("eventId="+this.eveId)
    }

    addClass(event){
        let index = event.currentTarget.dataset.rowIndex;
        let flipElement = this.template.querySelector('[data-id="' + index + '"]');
        flipElement.classList.add('class1');
    }

    removeClass(event){
        let index = event.currentTarget.dataset.rowIndex;
        let flipElement = this.template.querySelector('[data-id="' + index + '"]');
        flipElement.classList.remove('class1');
    }
}