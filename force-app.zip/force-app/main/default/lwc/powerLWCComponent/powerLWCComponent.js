import { LightningElement } from 'lwc';
export default class PowerLWCComponent extends LightningElement {

}