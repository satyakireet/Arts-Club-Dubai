import { LightningElement,wire } from 'lwc';
import getRecordsDetails from '@salesforce/apex/MemberEventsDirectory.getRecordsDetails';
export default class EventsDetailsArtsClub extends LightningElement {
    recordId='a035h00000csne5AAA';
   @wire(getRecordsDetails, {eventId:'$recordId'}) eventdata;
   memberLoggedIn = true;
   ShowEventDetails=false;
   noofguest=1;

   handleDetailsClick(){
       this.ShowEventDetails = true;
       this.memberLoggedIn = false;
   }

   handleContinue(){
      this.showForm = true; 
   }

   handleAdd(){
       this.noofguest = this.noofguest +1;
   }
   handleSubstract(){
        this.noofguest = this.noofguest -1;
   }
}