import { LightningElement } from 'lwc';
import Homepage from '@salesforce/resourceUrl/Homepage';
export default class Landingpagecarousel extends LightningElement {
 image1 = Homepage + '/images/image1.jpg';
 image1 = Homepage + '/images/image2.jpg';
 image1 = Homepage + '/images/image3.jpg';

}