import { LightningElement, api, wire } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import getRecords from '@salesforce/apex/MemberEventsDirectory.getRecords';
import abcd from '@salesforce/resourceUrl/UpcomingEvents';
export default class FlipcardSalesforce extends NavigationMixin(LightningElement) {
    imageUrl='abcd';
    @api recordId;
    showEvent=true;
    @api eveId;
    @wire(getRecords) contactData;

    navigatetoDetails(event){
        this.showEvent=false;
        this.eveId=event.currentTarget.dataset.id;
        window.location.replace('https://theartsclub-dev-ed.develop.my.site.com/s/member-event/'+this.eveId)
       //  window.location.replace`https://theartsclub-dev-ed.develop.my.site.com/s/member-event/?C__recordId=${this.recordId}`;
    //    this[NavigationMixin.Navigate]({
    //   type: 'standard__webPage',
    //   attributes: {
      
        
    //     url:'https://theartsclub-dev-ed.develop.my.site.com/s/member-event/a035h00000bDAoNAAW/louboutin-event'
        
    //   }
    // });
        console.log("eventId="+this.eveId)
    }

    addClass(event){
        let index = event.currentTarget.dataset.rowIndex;
        let flipElement = this.template.querySelector('[data-id="' + index + '"]');
        flipElement.classList.add('class1');
    }

    removeClass(event){
        let index = event.currentTarget.dataset.rowIndex;
        let flipElement = this.template.querySelector('[data-id="' + index + '"]');
        flipElement.classList.remove('class1');
    }

    item = {
    Event_Image_URL__c: 'URL_OF_EVENT_IMAGE'
  };

  handleImageClick() {
    console.log('test')
    this[NavigationMixin.Navigate]({
      type: 'Custom__component',
      attributes: {
      
        componentName: 'eventCmp'
        
      },state:{
        c__recordId: this.eveId

      }
    });
  }

}