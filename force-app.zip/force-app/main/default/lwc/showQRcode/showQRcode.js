import { LightningElement, api } from 'lwc';
import qrcode from './qrcode.js';

export default class ShowQRcode extends LightningElement {

    @api recordId;

    renderedCallback() {
        console.log('recordId-->' + this.recordId)
        const qrCodeGenerated = new qrcode(0, 'H');
        var strForGenearationOfQRCode = 'https://theartsclub-dev-ed.develop.lightning.force.com/' + this.recordId;
        qrCodeGenerated.addData(strForGenearationOfQRCode);
        qrCodeGenerated.make();
        let element = this.template.querySelector(".qrcode2");
        element.innerHTML = qrCodeGenerated.createSvgTag({});
    }

}