import { LightningElement } from 'lwc';

export default class NfcReaderComponent extends LightningElement {
    async handleScan() {
        console.log('User clicked scan button');
        // if ('NDEFReader' in window) {
        //     const ndef = new NDEFReader();
        // window, alert('7')
        // window, alert('8')
        // const ndef = new NDEFReader();
        // window, alert('10')
        // ndef.scan().then(() => {
        //     console.log("Scan started successfully.");
        //     ndef.onreadingerror = () => {
        //         console.log("Cannot read data from the NFC tag. Try another one?");
        //         window.alert("Cannot read data from the NFC tag. Try another one?");
        //     };
        //     ndef.onreading = event => {
        //         console.log("NDEF message read.");
        //         window.alert("NDEF message read.");
        //     };
        // }).catch(error => {
        //     console.log(`Error! Scan failed to start: ${error}.`);
        //     window.alert(`Error! Scan failed to start: ${error}.`);
        // });
        try {
            const ndef = new NDEFReader();
            await ndef.scan();
            console.log("> Scan started");
            window.alert("> Scan started");
            ndef.addEventListener("readingerror", () => {
                console.log("Argh! Cannot read data from the NFC tag. Try another one?");
            });

            ndef.addEventListener("reading", ({ message, serialNumber }) => {
                console.log(`> Serial Number: ${serialNumber}`);
                console.log(`> Records: (${message.records.length})`);
            });
        } catch (error) {
            console.log("Argh! " + error);
            window.alert("Argh! " + error);
        }
        // } else {
        //     console.log("Web NFC is not supported.");
        //     window.alert("Web NFC is not supported.");
        // }
    }
    async handleWrite() {
        console.log('User clicked Write button');
        if ('NDEFReader' in window) {
            const ndef = new NDEFReader();
            try {
                await ndef.write("Hello world!");
                console.log("> Message written");
                window.alert("> Message written");
            } catch (error) {
                console.log("Argh! " + error);
                window.alert("Argh! " + error);
            }
        } else {
            console.log("Web NFC is not supported.");
            window.alert("Web NFC is not supported.");
        }

    }
}