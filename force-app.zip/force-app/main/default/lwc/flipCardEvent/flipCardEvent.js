import { LightningElement, api, wire } from 'lwc';
import getRecords from '@salesforce/apex/MemberEventsDirectory.getRecords';
import abcd from '@salesforce/resourceUrl/UpcomingEvents';
export default class FileCardEvent extends LightningElement {
    imageUrl='abcd';
    @api recordId;
    showEvent=true;
    eveId;
    @wire(getRecords) contactData;
    /*({error,data}){
        if(data){
            this.contactData = data;
            console.log('data is ' + JSON.stringify(data));
        }
        else{
            console.log('exception');
        }
    };*/

    /*connectedCallback() {
        console.log('test ' + )
    }*/

    navigatetoDetails(event){
        console.log('enter in nav')
        window.location.replace("https://theartsclub-dev-ed.develop.my.site.com/s/iframepage")
        this.showEvent=false;
        this.eveId=event.currentTarget.dataset.id;
        console.log("eventId="+this.eveId)
    }

    addClass(event){
        let index = event.currentTarget.dataset.rowIndex;
        let flipElement = this.template.querySelector('[data-id="' + index + '"]');
        flipElement.classList.add('class1');
    }

    removeClass(event){
        let index = event.currentTarget.dataset.rowIndex;
        let flipElement = this.template.querySelector('[data-id="' + index + '"]');
        flipElement.classList.remove('class1');
    }
}